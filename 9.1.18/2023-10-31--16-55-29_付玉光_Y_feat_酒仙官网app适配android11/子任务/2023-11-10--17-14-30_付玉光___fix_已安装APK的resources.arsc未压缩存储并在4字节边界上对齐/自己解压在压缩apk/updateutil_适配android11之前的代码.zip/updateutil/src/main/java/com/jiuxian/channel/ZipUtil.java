package com.jiuxian.channel;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

public class ZipUtil {
    private static final int BUFFER = 1024;

    public ZipUtil() {
    }

    public static void zipFile(String zipDir, String zipFile) throws Exception {
        List<File> fileList = getSubFiles(new File(zipDir));
        ZipOutputStream zos = null;

        try {
            zos = new ZipOutputStream(new FileOutputStream(zipFile));
            ZipEntry ze = null;
            byte[] buf = new byte[1024];
            //int readLen = false;
            InputStream is = null;

            for(int i = 0; i < fileList.size(); ++i) {
                File f = (File)fileList.get(i);
                ze = new ZipEntry(getAbsFileName(zipDir, f));
                ze.setSize(f.length());
                ze.setTime(f.lastModified());
                zos.putNextEntry(ze);

                try {
                    is = new BufferedInputStream(new FileInputStream(f));

                    int readLen;
                    while((readLen = is.read(buf, 0, 1024)) != -1) {
                        zos.write(buf, 0, readLen);
                    }
                } finally {
                    close((InputStream)is);
                }
            }
        } finally {
            if (zos != null) {
                zos.close();
            }

        }

    }

    public static void upZipFile(String zipFile, String zipDir) throws Exception {
        File file = new File(zipDir);
        if (!file.exists()) {
            file.mkdirs();
        }

        ZipFile zfile = null;
        OutputStream os = null;
        BufferedInputStream is = null;

        try {
            zfile = new ZipFile(zipFile);
            Enumeration<? extends ZipEntry> zList = zfile.entries();
            ZipEntry ze = null;
            byte[] buf = new byte[1024];

            while(zList.hasMoreElements()) {
                ze = (ZipEntry)zList.nextElement();
                if (ze.isDirectory()) {
                    File f = new File(zipDir + ze.getName());
                    f.mkdir();
                } else {
                    try {
                        os = new BufferedOutputStream(new FileOutputStream(getRealFileName(zipDir, ze.getName())));
                        is = new BufferedInputStream(zfile.getInputStream(ze));
                        boolean var9 = false;

                        int readLen;
                        while((readLen = is.read(buf, 0, 1024)) != -1) {
                            os.write(buf, 0, readLen);
                        }
                    } finally {
                        close((InputStream)is);
                        close((OutputStream)os);
                    }
                }
            }
        } finally {
            if (zfile != null) {
                zfile.close();
            }

        }

    }

    private static String getAbsFileName(String baseDir, File realFileName) {
        File real = realFileName;
        File base = new File(baseDir);
        String ret = realFileName.getName();

        while(true) {
            real = real.getParentFile();
            if (real == null || real.equals(base)) {
                return ret;
            }

            ret = real.getName() + "/" + ret;
        }
    }

    private static List<File> getSubFiles(File baseDir) {
        List<File> ret = new ArrayList();
        File[] tmp = baseDir.listFiles();

        for(int i = 0; i < tmp.length; ++i) {
            if (tmp[i].isFile()) {
                ret.add(tmp[i]);
            }

            if (tmp[i].isDirectory()) {
                ret.addAll(getSubFiles(tmp[i]));
            }
        }

        return ret;
    }

    public static File getRealFileName(String baseDir, String absFileName) {
        String[] dirs = absFileName.split("/");
        File ret = new File(baseDir);
        if (dirs.length > 1) {
            for(int i = 0; i < dirs.length - 1; ++i) {
                ret = new File(ret, dirs[i]);
            }

            if (!ret.exists()) {
                ret.mkdirs();
            }
        }

        return new File(ret, dirs[dirs.length - 1]);
    }

    private static void close(OutputStream out) {
        if (out != null) {
            try {
                out.close();
            } catch (IOException var2) {
            }
        }

    }

    private static void close(InputStream in) {
        if (in != null) {
            try {
                in.close();
            } catch (IOException var2) {
            }
        }

    }
}
