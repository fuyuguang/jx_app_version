package com.jiuxian.channel;


import java.io.BufferedReader;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ChannelUtil {
    private static final int THREAD_POOL_SIZE = 5;
    private static final String RELEASE_DIR_NAME = "channels";
    private static final String APK_CHANNEL_TARGET_FILE = "/META-INF/channel.txt";
    private static  String APK_KEYSTORY_FILE;

    public ChannelUtil() {
    }

    public static void main(String[] args) {
        if (args != null && args.length >= 4) {
            APK_KEYSTORY_FILE = args[4];
            createChannleApks(args[0], args[1], args[2], args[3]);
        }

    }

    private static void createChannleApks(String apkDir, final String oldChannel, String channelsFile, String key) {
        BufferedReader reader = null;
        ExecutorService executorService = Executors.newFixedThreadPool(5);

        try {
            final String apkFile = getApkFilePath(apkDir, channelsFile);
            String[] channelArray = getChannels(channelsFile, key);
            String[] var11 = channelArray;
            int var10 = channelArray.length;


            for(int var9 = 0; var9 < var10; ++var9) {
                String channel = var11[var9];
                if (channel != null) {
                    channel = channel.trim();
                    if (!"".equals(channel)) {
                        String finalChannel = channel;
                        long temTimeStem = System.currentTimeMillis();
                        ChannelUtil.createChannelApk(apkFile, oldChannel, finalChannel);
                        System.out.println(finalChannel + " apk need time : "+TimeUtil.execTime(temTimeStem));
                        System.out.println("");




//                        String finalChannel = channel;
//                        int finalVar = var9;
//                        executorService.execute(new Runnable() {
//                            public void run() {
//                                try {
//
//                                    long sleepTime = 10 * finalVar%5 * 1000;
//                                    Thread.sleep(sleepTime);
//                                    System.out.println("sleep time "+sleepTime);
//                                    long temTimeStem = System.currentTimeMillis();
//                                    ChannelUtil.createChannelApk(apkFile, oldChannel, finalChannel);
//
//                                    System.out.println(finalChannel + " apk need time : "+TimeUtil.execTime(temTimeStem));
//                                    System.out.println("");
//
//
//                                } catch (Exception var2) {
//                                    var2.printStackTrace();
//                                }
//                            }
//                        });


//                        executorService.execute(new Runnable() {
//                            public void run() {
//                                try {
//                                    ChannelUtil.createChannelApk(apkFile, oldChannel, finalChannel);
//                                } catch (Exception var2) {
//                                    var2.printStackTrace();
//                                }
//
//                                System.out.println(finalChannel);
//                            }
//                        });
                    }
                }
            }


            File apk = new File(apkFile);
            File releaseDir = new File(apk.getParent(), "channels");
            if (releaseDir.listFiles().length == var10){
                System.out.println("");
                System.out.println("success all apk is complete");
            }else{

                System.out.println("");
                System.out.println("fail apk is missing");

            }

        } catch (Exception var20) {
            throw new RuntimeException(var20);
        } finally {
            if (reader != null) {
                try {
                    ((BufferedReader)reader).close();
                } catch (IOException var19) {
                }
            }

            executorService.shutdown();
        }

    }

    private static String getApkFilePath(String apkDir, String channelsFile) throws Exception {
        Properties properties = new Properties();
        properties.load(new FileInputStream(new File(channelsFile)));
        String versionName = properties.getProperty("app.version.name");
        File dir = new File(apkDir + "jiuxian_" + versionName);
        File[] files = dir.listFiles();
        List<File> apkFiles = new ArrayList();
        File[] var10 = files;
        int var9 = files.length;

        for(int var8 = 0; var8 < var9; ++var8) {
            File file = var10[var8];
            if (file.isFile() && !file.getName().contains("_dev") && file.getName().endsWith(".apk")) {
                apkFiles.add(file);
            }
        }

        Collections.sort(apkFiles, new Comparator<File>() {
            public int compare(File o1, File o2) {
                return o1.getName().compareTo(o2.getName());
            }
        });
        return ((File)apkFiles.get(apkFiles.size() - 1)).getAbsolutePath();
    }

    private static String[] getChannels(String channelsFile, String key) throws Exception {
        Properties properties = new Properties();
        properties.load(new FileInputStream(new File(channelsFile)));
        String channels = properties.getProperty(key);
        return channels.split(",");
    }

    private synchronized static void createChannelApk(String apkFile, String oldChannel, String targetChannel) throws Exception {
        File apk = new File(apkFile);
        String apkName = apk.getName();
        String apkDir = apk.getParent();
        File releaseDir = new File(apkDir, "channels");
        if (!releaseDir.exists()) {
            releaseDir.mkdirs();
        }

        String targetApkFileJiagu = releaseDir.getPath() + File.separator + apkName.replace(oldChannel, targetChannel+"_jiagu");
        String targetApkFileSign = releaseDir.getPath() + File.separator + apkName.replace(oldChannel, targetChannel+"_sign");
        String targetApkFileAlign = releaseDir.getPath() + File.separator + apkName.replace(oldChannel, targetChannel+"_zipAlign");

        String targetApkFile = releaseDir.getPath() + File.separator + apkName.replace(oldChannel, targetChannel);

        String targetApkZipDir = targetApkFile.replace(".apk", "");
        ZipUtil.upZipFile(apkFile, targetApkZipDir);
        setChannelToApkDir(targetApkZipDir, targetChannel);
        ZipUtil.zipFile(targetApkZipDir, targetApkFile);
        FileUtil.deleteDir(new File(targetApkZipDir));


        String targetApkFileName = new File(targetApkFile).getName();
        System.out.println("");
        System.out.println(targetChannel);
        System.out.println("step1  origin file :  "+targetApkFileName+"  fileSize  : "+FileSizeUtil.getAutoFileOrFilesSize(targetApkFile));











//        try {
//
////        Runtime.getRuntime().exec("./jiagu ./build/apk/jiuxian_$appVersion_$channel.apk jiagu_output.apk base.conf");
//            Runtime.getRuntime().exec("/opt/newlegu/jiagu "+targetApkFile+" "+targetApkFile+" base.conf" + "  ");
//            System.out.println(targetApkFileName +  "  step 2  jiagu file size  : "+FileSizeUtil.getAutoFileOrFilesSize(targetApkFile));
//
//
//        }finally {
//            System.out.println("");
//
//            Runtime.getRuntime().exec("jarsigner -verbose -keystore ./../jiuxian/release.keystore -storepass 415263 -signedjar " + targetApkFile + " -digestalg SHA1 -sigalg MD5withRSA " + targetApkFile + " jiuxian_alias");
//            System.out.println(targetApkFileName + "  step 3  sign file size  : "+FileSizeUtil.getAutoFileOrFilesSize(targetApkFile));
//
//            System.out.println("");
//        }



        boolean isSuccessWithJiagu = false;
        boolean isSuccessWithSign = false;
        boolean isZipAlignSuccess = false;

        // 1............
        Process shellProcess = null;
        BufferedReader shellErrorResultReader = null;;
        BufferedReader shellInfoResultReader = null;
        long temTimeStem = System.currentTimeMillis();
        try {
//            shellProcess = Runtime.getRuntime().exec("/opt/newlegu/jiagu "+targetApkFile+" "+targetApkFile+" base.conf");
            shellProcess = Runtime.getRuntime().exec("./shell/jiagu "+targetApkFile+" "+targetApkFileJiagu+" ./shell/base.conf");
            shellErrorResultReader = new BufferedReader(new InputStreamReader(shellProcess.getErrorStream()));
            shellInfoResultReader =  new BufferedReader(new InputStreamReader(shellProcess.getInputStream()));

            String infoLine,errorLine;
            while ((infoLine = shellInfoResultReader.readLine()) != null) {
                System.out.println("jiagu Input log : "+infoLine);
            }
            while ((errorLine = shellErrorResultReader.readLine()) != null) {
                System.out.println("jiagu error log : "+errorLine);
            }
            // 等待程序执行结束并输出状态
            int exitCode = shellProcess.waitFor();
            if (isSuccessWithJiagu = (0 == exitCode)) {
                System.out.println("step2  jiagu success File size  : "+FileSizeUtil.getAutoFileOrFilesSize(targetApkFileJiagu) + TimeUtil.execTime(temTimeStem));
                File targetApkOriginFile = new File(targetApkFile);
                if (targetApkOriginFile.exists()){
                    //删除原始包
                    System.out.println("step2   delete originFile  : " + targetApkOriginFile.getName() +"  success : "+ targetApkOriginFile.delete());
                }
            } else {
                System.out.println("step2  fail     exitCode : "+exitCode);
            }
        } catch (Exception e) {
            System.out.println("");
            System.out.println("step2  fail  Exception "+ e.toString());
        } finally {

            close(shellInfoResultReader);
            close(shellErrorResultReader);

            if (null != shellProcess) {
                shellProcess.destroy();
            }

            if (!isSuccessWithJiagu){
                //删除原始包
                File targetOriginApkFile = new File(targetApkFile);
                FileUtil.deleteDir(targetOriginApkFile);
                System.out.println("step2  fail   delete targetApkFile file "+targetOriginApkFile.getName());
                return;
            }
        }






        if (isSuccessWithJiagu){

            //./build-tools/31.0.0/zipalign  -fv 4 ./Downloads/jiuxian_9.0.2_sougou.apk ./jiuxian_9.0.2_sougou1.apk
            try {

                String zipalignPath = "/usr/local/android-sdk-linux/build-tools/30.0.2/zipalign";
                //String zipalignPath2 = "zipalign";

                temTimeStem = System.currentTimeMillis();
                shellProcess = Runtime.getRuntime().exec(zipalignPath+"  -f -v 4 "+targetApkFileJiagu+" "+targetApkFileAlign);
                shellErrorResultReader = new BufferedReader(new InputStreamReader(shellProcess.getErrorStream()));
                shellInfoResultReader = new BufferedReader(new InputStreamReader(shellProcess.getInputStream()));

                String infoLine, errorLine;
                while ((infoLine = shellInfoResultReader.readLine()) != null) {
                    //System.out.println("\tsign  Input log : "+infoLine);
                }
                while ((errorLine = shellErrorResultReader.readLine()) != null) {
                    System.out.println("\tzipalign  error  log : " + errorLine);
                }
                // 等待程序执行结束并输出状态
                int exitCode = shellProcess.waitFor();
                if (isZipAlignSuccess = (0 == exitCode)) {
                    System.out.println("step3  zipalign success fileSize  : " + FileSizeUtil.getAutoFileOrFilesSize(targetApkFileAlign) + TimeUtil.execTime(temTimeStem));
                    File targetApkFileJiaguFile = new File(targetApkFileJiagu);
                    if (targetApkFileJiaguFile.exists()){
                        //对齐成功，删除加固包
                        System.out.println("step3  delete  jiagu file  : " + targetApkFileJiaguFile.getName() +"  success : "+ targetApkFileJiaguFile.delete());
                    }

                } else {
                    System.out.println(targetApkFileName + "  step4 zipalign fail   exitCode : " + exitCode);
                }
            } catch (Exception e) {
                System.out.println("");
                System.out.println("  step3  zipalign fail  Exception  : " + e.toString());
            } finally {

                close(shellInfoResultReader);
                close(shellErrorResultReader);

                if (null != shellProcess) {
                    shellProcess.destroy();
                }

                if (!isZipAlignSuccess){
                    //删除加固错误的包
                    File targetApkFileJiaguFile = new File(targetApkFileJiagu);
                    FileUtil.deleteDir(targetApkFileJiaguFile);
                    System.out.println("step3   zipalign fail   delete  Jiag file  : "+targetApkFileJiaguFile.getName());
                    return;
                }
            }
        }





        if (isZipAlignSuccess) {
            //2........
            try {
                temTimeStem = System.currentTimeMillis();
                //shellProcess = Runtime.getRuntime().exec("jarsigner -verbose -keystore ./../jiuxian/release.keystore -storepass 415263 -signedjar " + targetApkFile + " -digestalg SHA1 -sigalg MD5withRSA " + targetApkFile + " jiuxian_alias");
                //shellProcess = Runtime.getRuntime().exec("jarsigner -verbose -keystore " + APK_KEYSTORY_FILE + " -storepass 415263 -signedjar " + targetApkFileSign + " -digestalg SHA1 -sigalg MD5withRSA " + targetApkFileJiagu + " jiuxian_alias");


                // apksigner sign --ks (签名地址) --ks-key-alias (别名) --out (签名后的apk地址) (待签名apk地址)

//                                                                                                          apksigner sign --ks=xxx.keystore --min-sdk-version=17 --in=xxx.apk --out=xxx_sign.apk
                shellProcess = Runtime.getRuntime().exec("/usr/local/android-sdk-linux/build-tools/30.0.2/apksigner sign --ks "+APK_KEYSTORY_FILE+" --min-sdk-version=17 --v1-signing-enabled true --v2-signing-enabled true --ks-key-alias jiuxian_alias --ks-pass pass:415263 --key-pass pass:415263 --out "+targetApkFile+" --in "+targetApkFileAlign);

                shellErrorResultReader = new BufferedReader(new InputStreamReader(shellProcess.getErrorStream()));
                shellInfoResultReader = new BufferedReader(new InputStreamReader(shellProcess.getInputStream()));

                String infoLine, errorLine;
                while ((infoLine = shellInfoResultReader.readLine()) != null) {
                    //System.out.println("\tsign  Input log : "+infoLine);
                }
                while ((errorLine = shellErrorResultReader.readLine()) != null) {
                    System.out.println("\tsign  error  log : " + errorLine);
                }
                // 等待程序执行结束并输出状态
                int exitCode = shellProcess.waitFor();
                if (isSuccessWithSign = (0 == exitCode)) {
                    System.out.println("step4  sign success fileSize  : " + FileSizeUtil.getAutoFileOrFilesSize(targetApkFile) + TimeUtil.execTime(temTimeStem));
                    File targetApkFileAlignFile = new File(targetApkFileAlign);
                    if (targetApkFileAlignFile.exists()){
                        //删除对齐包
                        System.out.println("step4   delete zipalign file  : " + targetApkFileAlignFile.getName() +"  success : "+ targetApkFileAlignFile.delete());
                    }
                } else {
                    System.out.println("step4  sign fail   exitCode : " + exitCode);
                }
            } catch (Exception e) {
                System.out.println("");
                System.out.println("step4  sign fail  Exception  : " + e.toString());
            } finally {

                close(shellInfoResultReader);
                close(shellErrorResultReader);

                if (null != shellProcess) {
                    shellProcess.destroy();
                }


                if (!isSuccessWithSign){
                    //删除 对齐的包
                    File targetApkFileAlignFile = new File(targetApkFileAlign);
                    FileUtil.deleteDir(targetApkFileAlignFile);
                    System.out.println("step4   sign fail   delete  zipalign file  : "+targetApkFileAlignFile.getName());
                    //System.out.println("step3  fail   delete file : "+targetApkFileJiaguFile.getName());
                    return;
                }

            }
        }

    }


    public static void close(Closeable closeable){
        if (null != closeable) {
            try {
                closeable.close();
            } catch (IOException e) {
                System.out.println("io file close exception ：" + e.toString());
            }
        }

    }

    public void haha(String commond ,Runnable run){
        Process shellProcess = null;

        BufferedReader shellErrorResultReader = null;;
        BufferedReader shellInfoResultReader = null;
        try {
            shellProcess = Runtime.getRuntime().exec(commond);
            shellErrorResultReader = new BufferedReader(new InputStreamReader(shellProcess.getErrorStream()));
            shellInfoResultReader =  new BufferedReader(new InputStreamReader(shellProcess.getInputStream()));

            String infoLine;
            while ((infoLine = shellInfoResultReader.readLine()) != null) {

                System.out.println("InputStream log : "+infoLine);
            }
            String errorLine;
            while ((errorLine = shellErrorResultReader.readLine()) != null) {
                System.out.println("errorStream log : "+errorLine);
            }
            // 等待程序执行结束并输出状态
            int exitCode = shellProcess.waitFor();
            if (0 == exitCode) {
                System.out.println("脚本文件执行成功: : "+exitCode);
                if (run != null){
                    run.run();
                }
            } else {
                System.out.println("脚本文件执行 失败:" + exitCode);
            }
        } catch (Exception e) {
            System.out.println("shell脚本执行错误");
        } finally {
            close(shellInfoResultReader);
            close(shellErrorResultReader);
            if (null != shellProcess) {
                shellProcess.destroy();
            }
        }


    }

    private static void setChannelToApkDir(String apkDir, String channel) throws Exception {
        String targetChannelFile = apkDir + "/META-INF/channel.txt";
        FileOutputStream fileOutputStream = null;

        try {
            fileOutputStream = new FileOutputStream(targetChannelFile);
            fileOutputStream.write(channel.getBytes());
        } finally {
            FileUtil.close(fileOutputStream);
        }

    }
}
