package com.jiuxian.channel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.FileChannel;

public class FileUtil {
    public FileUtil() {
    }

    public static boolean deleteDir(File dir) {
        if (dir.isDirectory()) {
            String[] children = dir.list();

            for(int i = 0; i < children.length; ++i) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
        }

        return dir.delete();
    }

    public static void fileCopy(String sourceFile, String targetFile) throws Exception {
        File source = new File(sourceFile);
        File target = new File(targetFile);
        if (target.exists()) {
            target.delete();
        }

        FileChannel in = null;
        FileChannel out = null;
        FileInputStream inStream = null;
        FileOutputStream outStream = null;

        try {
            inStream = new FileInputStream(source);
            outStream = new FileOutputStream(target);
            in = inStream.getChannel();
            out = outStream.getChannel();
            in.transferTo(0L, in.size(), out);
        } finally {
            close((InputStream)inStream);
            close(in);
            close((OutputStream)outStream);
            close(out);
        }

    }

    public static void close(OutputStream out) {
        if (out != null) {
            try {
                out.close();
            } catch (IOException var2) {
            }
        }

    }

    public static void close(InputStream in) {
        if (in != null) {
            try {
                in.close();
            } catch (IOException var2) {
            }
        }

    }

    public static void close(FileChannel channnel) {
        if (channnel != null) {
            try {
                channnel.close();
            } catch (IOException var2) {
            }
        }

    }
}
