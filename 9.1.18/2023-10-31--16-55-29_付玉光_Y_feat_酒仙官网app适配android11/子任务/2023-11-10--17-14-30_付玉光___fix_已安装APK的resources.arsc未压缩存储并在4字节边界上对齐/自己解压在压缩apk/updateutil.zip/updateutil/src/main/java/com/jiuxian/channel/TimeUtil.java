package com.jiuxian.channel;

import java.text.DecimalFormat;

/**
 * * desc :
 * Created by fyg on 2021/9/18.
 * E-Mail ：2355245065@qq.com
 * Wechat :fyg13522647431
 * Tel : 13522647431
 */
public class TimeUtil {


    public static String execTime(long temTimeStem) {
        return " executeTime : "+TimeUtil.handleTime(System.currentTimeMillis() - temTimeStem).getFormatTime();
    }


    public static class TimeInfo {
        public int mDays;
        public int mHours;
        public int mMinutes;
        public int mSeconds;
        public String mDescription = "";

        public String getFormatTime(){

            String time = "";
            if (mDays > 0){
                time = String.format("%s day %s hours %s m %s s %s",String.valueOf(mDays),String.valueOf(mHours),String.valueOf(mMinutes),String.valueOf(mSeconds),mDescription);
            }else if (mHours > 0){

                time = String.format("%s hours %s m %s s %s",String.valueOf(mHours),String.valueOf(mMinutes),String.valueOf(mSeconds),mDescription);
            }else if (mMinutes > 0){
                time = String.format("%s m %s s %s",String.valueOf(mMinutes),String.valueOf(mSeconds),mDescription);
            }else if (mSeconds > 0){
                time = String.format("%s s %s",String.valueOf(mSeconds),mDescription);
            }
            return time;
        }

        public String getDays() {
            return formatTime(mDays);
        }

        public String getHours() {
            return formatTime(mHours);
        }

        public String getMinutes() {
            return formatTime(mMinutes);
        }

        public String getSeconds() {
            return formatTime(mSeconds);
        }

        private static String formatTime(int time) {
            if (time < 0) {
                time = 0;
            }
            DecimalFormat format = new DecimalFormat("00");
            return format.format(time);
        }
    }

    public static final float ss = 1000f;
    public static final int mi = (int) (ss * 60);
    public static final int hh = mi * 60;
    public static final int dd = hh * 24;

    public static TimeInfo handleTime(long millisUntilFinished) {
        TimeInfo timeInfo = new TimeInfo();
        timeInfo.mDays = (int) (millisUntilFinished / dd);
        timeInfo.mHours = (int) ((millisUntilFinished - timeInfo.mDays * dd) / hh);
        timeInfo.mMinutes = (int) ((millisUntilFinished - timeInfo.mDays * dd - timeInfo.mHours * hh) / mi);
        timeInfo.mSeconds = (int) ((millisUntilFinished - timeInfo.mDays * dd - timeInfo.mHours * hh - timeInfo.mMinutes * mi) / ss);
        return timeInfo;
    }
}
